package com.pain.advice;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/**
 * Created by meilb on 2017/12/11.
 */
public class AroundAdvice implements MethodInterceptor {

    public Object invoke(MethodInvocation invocation) throws Throwable {
        Object[] args = invocation.getArguments();
        System.out.println("Method: " + invocation.getMethod().getName());
        System.out.println("Arguments: ");
        for (Object arg : args) {
            System.out.println(String.valueOf(arg));
        }
        System.out.println("around advice: before method call");
        Object obj = invocation.proceed();
        System.out.println("around advice: after method call");
        return obj;
    }
}
