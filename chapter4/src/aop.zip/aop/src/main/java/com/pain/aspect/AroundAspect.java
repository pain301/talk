package com.pain.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

/**
 * Created by meilb on 2017/12/11.
 */
@Aspect
public class AroundAspect {
    @Around("execution(* update(..))")
    public Object aroundAdvice(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("AroundAspect args: ");
        Object[] args = pjp.getArgs();
        for (Object arg : args) {
            System.out.println(String.valueOf(arg));
        }
        System.out.println(String.format("Signature: %s", pjp.getSignature()));
        System.out.println(String.format("Classname: %s", pjp.getTarget().getClass()));
        return pjp.proceed();
    }
}
