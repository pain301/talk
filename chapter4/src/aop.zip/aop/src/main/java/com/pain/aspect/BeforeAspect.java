package com.pain.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 * Created by meilb on 2017/12/11.
 */
@Aspect
public class BeforeAspect {
    @Before("execution(* getUsername(..))")
    public void beforeAdvice() {
        System.out.println("BeforeAspect");
    }
}
