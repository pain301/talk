package com.pain.advice;

import org.springframework.aop.MethodBeforeAdvice;

import java.lang.reflect.Method;

/**
 * Created by meilb on 2017/12/11.
 */
public class BeforeAdvice implements MethodBeforeAdvice {
    public void before(Method method, Object[] objects, Object o) throws Throwable {
        System.out.println("Method: " + method.getName());
        System.out.println("Arguments: ");
        for (Object obj : objects) {
            System.out.println(String.valueOf(obj));
        }
        System.out.println("before advice: before method call");
    }
}
