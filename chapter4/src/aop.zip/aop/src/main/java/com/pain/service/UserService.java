package com.pain.service;

/**
 * Created by meilb on 2017/12/11.
 */
public interface UserService {

    Long createUser(String username);

    int update(Long userId, String username);

    String getUsername(Long userId);
}
