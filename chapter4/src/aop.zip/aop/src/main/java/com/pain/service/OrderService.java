package com.pain.service;

import java.sql.SQLException;

/**
 * Created by meilb on 2017/12/11.
 */
public class OrderService {
    public Long createOrder() {
        throw new RuntimeException("Create order failed");
    }

    public void updateOrder(Long orderId) throws SQLException {
        throw new SQLException("Update order failed");
    }
}
