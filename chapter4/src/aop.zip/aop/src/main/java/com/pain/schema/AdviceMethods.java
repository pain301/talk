package com.pain.schema;

import org.aspectj.lang.ProceedingJoinPoint;

/**
 * Created by meilb on 2017/12/11.
 */
public class AdviceMethods {
    public void before(Long userId) {
        System.out.println(String.format("beforeAdvice, userId: %d", userId));
    }

    public void afterReturning(int retVal) {
        System.out.println("afterReturning");
    }

    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("aroundMethod");
        return pjp.proceed();
    }

    public void afterThrowing(Exception e) {
        System.out.println("afterThrowingMethod: " + e.getMessage());
    }

    public void after() {
        System.out.println("afterMethod");
    }
}
