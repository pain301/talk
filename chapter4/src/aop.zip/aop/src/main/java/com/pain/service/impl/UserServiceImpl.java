package com.pain.service.impl;

import com.pain.service.UserService;

/**
 * Created by meilb on 2017/12/11.
 */
public class UserServiceImpl implements UserService {
    public Long createUser(String username) {
        System.out.println(String.format("create user, username: %s", username));
        return Long.valueOf(0);
    }

    public int update(Long userId, String username) {
        System.out.println(String.format("Update user, id: %d, username: %s", userId, username));
        return 0;
    }

    public String getUsername(Long userId) {
        System.out.println(String.format("Get username, id: %d", userId));
        return "pain";
    }
}
