package com.pain;

import com.pain.aspect.BeforeAspect;
import com.pain.advice.BeforeAdvice;
import com.pain.service.OrderService;
import com.pain.service.UserService;
import com.pain.service.impl.UserServiceImpl;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import java.sql.SQLException;

/**
 * Created by meilb on 2017/12/11.
 */
public class TestAop {

    @Test
    public void around() {
        String path = "beans.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(path);
        UserService userService = (UserService) ctx.getBean("userService");
        userService.getUsername(Long.valueOf(1));
        userService.update(Long.valueOf(1), "pain");
    }

    @Test
    public void before() {
        UserService target = new UserServiceImpl();
        BeforeAdvice beforeAdvice = new BeforeAdvice();

        ProxyFactory proxyFactory = new ProxyFactory();
        proxyFactory.setInterfaces(target.getClass().getInterfaces());
        proxyFactory.setOptimize(true);
        proxyFactory.setTarget(target);
        proxyFactory.addAdvice(beforeAdvice);

        UserService userService = (UserService) proxyFactory.getProxy();
        userService.getUsername(Long.valueOf(1));
        userService.update(Long.valueOf(1), "pain");
    }

    @Test
    public void throwCGlib() {
        String path = "beans.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(path);
        OrderService orderService = (OrderService) ctx.getBean("orderService");
        try {
            orderService.createOrder();
        } catch (Exception e) {
        }

        try {
            orderService.updateOrder(Long.valueOf(1));
        } catch (SQLException e) {
        }
    }

    @Test
    public void testAspect() {
        UserService target = new UserServiceImpl();
        AspectJProxyFactory factory = new AspectJProxyFactory();

        factory.setTarget(target);
        factory.addAspect(BeforeAspect.class);

        UserService userService = factory.getProxy();
        userService.getUsername(Long.valueOf(1));
        userService.update(Long.valueOf(1), "pain");
    }

    @Test
    public void testAspectConfig() {
        String path = "beans1.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(path);
        UserService userService = (UserService) ctx.getBean("userService");
        userService.getUsername(Long.valueOf(1));
        userService.update(Long.valueOf(1), "pain");
    }

    @Test
    public void testSchema() {
        String path = "beans2.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(path);
        UserService userService = (UserService) ctx.getBean("userService");
        userService.getUsername(Long.valueOf(1));
        userService.update(Long.valueOf(1), "pain");
    }
}
