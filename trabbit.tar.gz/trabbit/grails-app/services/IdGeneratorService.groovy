import com.google.common.util.concurrent.ThreadFactoryBuilder

import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class IdGeneratorService {

    private static final long START_STAMP = 1504195200000L

    private long lastStamp = START_STAMP
    private int sequence

    // gen with zookeeper
    private int nodeId = 1

    private final static long SEQUENCE_BIT = 12L
    private final static long MAX_SEQUENCE = ~(-1L << SEQUENCE_BIT)

    private final static long NODE_BIT = 10L
    private final static long MAX_NODE_NUM = ~(-1L << NODE_BIT)

    private final static long NODE_OFFSET = SEQUENCE_BIT
    private final static long TIMESTAMP_OFFSET = NODE_OFFSET + NODE_BIT

    private long getCurrentStamp() {
        return System.currentTimeMillis()
    }

    // 41 + 10 + 12
    public synchronized long genId() {
        long currentStamp = getCurrentStamp()

        if (currentStamp < lastStamp) {
            throw new RuntimeException("Clock moved backwards. Refusing to generate id")
        } else if (currentStamp == lastStamp) {
            sequence = (sequence + 1) & MAX_SEQUENCE

            if (sequence == 0L) {
                currentStamp = waitNextMillis()
            }
        } else {
            sequence = 0L
        }

        lastStamp = currentStamp

        long id = ((currentStamp - START_STAMP) << TIMESTAMP_OFFSET) | (nodeId << NODE_OFFSET) | sequence
        return id
    }

    private long waitNextMillis() {
        long millis = getCurrentStamp()
        while (millis <= lastStamp) {
            millis = getCurrentStamp()
        }
        return millis
    }

    public static void main(String[] args) {

        def service = new IdGeneratorService()
        println service.genId()
        def count = new AtomicInteger(0)
        def idSet = new CopyOnWriteArraySet()

        def threadFactory = new ThreadFactoryBuilder().setNameFormat("ID-GEN-%d").build()
        def executorService = Executors.newFixedThreadPool(5, threadFactory)

        for (int i = 0; i < 5; ++i) {
            executorService.submit(new Runnable() {
                @Override
                void run() {
                    while (!Thread.currentThread().isInterrupted()) {
                        count.incrementAndGet()
                        idSet.add(service.genId())
                    }
                }
            })
        }

        Thread.sleep(10000)
        System.out.println("count: " + count.intValue())
        System.out.println("actual count: " + idSet.size())

        executorService.shutdownNow()

        Thread.sleep(5000)

        System.out.println("count: " + count.intValue())
        System.out.println("actual count: " + idSet.size())

    }
}


