import org.apache.curator.framework.CuratorFramework
import org.apache.curator.framework.CuratorFrameworkFactory
import org.apache.curator.framework.imps.CuratorFrameworkState
import org.apache.curator.framework.recipes.locks.InterProcessMutex
import org.apache.curator.framework.state.ConnectionState
import org.apache.curator.framework.state.ConnectionStateListener
import org.apache.curator.retry.ExponentialBackoffRetry
import org.apache.curator.utils.ZKPaths
import org.apache.zookeeper.CreateMode

import java.util.concurrent.TimeUnit

class ZkNodeManager implements ConnectionStateListener {

    private CuratorFramework client

    private String connectString = "localhost:2181"

    private final static String NAMESPACE = "node-id-store"
    private final static String ROOT_PATH = "/"
    private final static long MAX_NODE_NUM = 1023
    private Long nodeId

    public static void main(String[] args) {
        def nodeManager = new ZkNodeManager()
        nodeManager.init()
        System.out.println("nodeId: " + nodeManager.nodeId)
    }

    public void init() {
        connect()
        client.getConnectionStateListenable().addListener(this)

        nodeId = buildNodeId()
    }

    private void connect() throws InterruptedException {
        client = CuratorFrameworkFactory.builder()
                .connectString(connectString)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .namespace(NAMESPACE)
                .sessionTimeoutMs(30000)
                .connectionTimeoutMs(30000)
                .build()

        if (CuratorFrameworkState.STARTED != client.getState()) {
            client.start()
        }

        if (!client.blockUntilConnected(5, TimeUnit.SECONDS)) {
            client.close()
            throw new RuntimeException("failed to connect to zookeeper")
        }
    }

    public long getNodeId() {
        if (nodeId == null) {
            try {
                Thread.sleep(5000)
            } catch (InterruptedException ignored) {
            }

            return getNodeId()
        }
        return nodeId
    }

    private long buildNodeId() throws Exception {
        InterProcessMutex lock = new InterProcessMutex(client, "/blo")
        try {
            if (lock.acquire(2, TimeUnit.MINUTES)) {
                String path = client.create().creatingParentsIfNeeded()
                        .withMode(CreateMode.EPHEMERAL_SEQUENTIAL)
                        .forPath(ZKPaths.makePath(ROOT_PATH, "0"), "0".getBytes())

                System.out.println("path: " + path)
                String str = path.replace("/", "")
                return Long.valueOf(str) % MAX_NODE_NUM
            } else {
            }
        } catch (Exception e) {
        } finally {
            try {
                lock.release()
            } catch (Exception ignored) {
            }
        }

        // 创建失败时递归调用再次尝试
        return buildNodeId()
    }

    @Override
    void stateChanged(CuratorFramework client, ConnectionState newState) {
        switch (newState) {
            case ConnectionState.LOST:
            case ConnectionState.SUSPENDED:

                try {
                    connect()
                } catch (InterruptedException ignored) {
                }
                break
            case ConnectionState.RECONNECTED:
                break
            default:
                break
        }
    }
}
