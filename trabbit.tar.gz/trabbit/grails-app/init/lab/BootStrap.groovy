package lab

import org.joda.time.DateTimeZone

class BootStrap {

    def init = { servletContext ->
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"))
        DateTimeZone.setDefault(DateTimeZone.UTC)

        // 创建初始账号
    }

    def destroy = {
    }
}
