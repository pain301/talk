import com.convertlab.kafka.KafkaProducerService
import com.convertlab.rabbitmq.ConnectionFactoryService
import com.convertlab.rabbitmq.RabbitMQService
import com.convertlab.rabbitmq.RabbitPublishService
import com.convertlab.redis.RedisService
import com.convertlab.unit.SuTenantService

beans = {
    redisService(RedisService)
    connectionFactoryService(ConnectionFactoryService)
    rabbitPublishService(RabbitPublishService, ref('connectionFactoryService'))
    rabbitMQService(RabbitMQService, "lab", ref('connectionFactoryService'), ref('rabbitPublishService'), ref('suTenantService'))

    suTenantService(SuTenantService, ref('redisService'))
    kafkaProducerService(KafkaProducerService, "customer2019", ref('suTenantService'))
}
