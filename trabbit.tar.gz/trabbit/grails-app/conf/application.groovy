grails.gorm.default.constraints = {
    '*'(nullable: true)
    name(nullable: false, blank: false, size: 1..32)
}