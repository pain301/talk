import ch.qos.logback.classic.AsyncAppender
import ch.qos.logback.classic.encoder.PatternLayoutEncoder
import ch.qos.logback.core.util.FileSize
import grails.util.BuildSettings
import grails.util.Environment
import groovy.json.JsonBuilder
import org.springframework.boot.logging.logback.ColorConverter

conversionRule("clr", ColorConverter)

def LOG_LEVEL_PATTERN = System.getProperty("LOG_LEVEL_PATTERN") ?: '%5p'
def PID = System.getProperty("PID") ?: "- "
def LOG_EXCEPTION_CONVERSION_WORD = System.getProperty("LOG_EXCEPTION_CONVERSION_WORD") ?: '%xEx'

def CONSOLE_LOG_PATTERN = "%clr(%d{yyyy-MM-dd HH:mm:ss.SSS}){faint} " +
        "%clr(${LOG_LEVEL_PATTERN}) %clr(${PID}){magenta} " +
        "%clr(---){faint} %clr([%15.15t]){faint}" +
        "%clr(%-40.40logger{39}){cyan} " +
        "%clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD}"

appender('CONSOLE', ConsoleAppender) {
    encoder(PatternLayoutEncoder) {
        pattern = CONSOLE_LOG_PATTERN
    }
}

def additionalFields = new JsonBuilder([
        "env"    : System.getProperty("grails.env"),
        "service": "lab"
]).toPrettyString()

appender("FILE", RollingFileAppender) {
    file = "/opt/log/stash/lab/lab.log"
    encoder(net.logstash.logback.encoder.LogstashEncoder) {
        customFields = additionalFields
        includeMdc = true
    }
    rollingPolicy(SizeAndTimeBasedRollingPolicy) {
        fileNamePattern = "/opt/log/stash/lab/lab-%d{yyyy-MM-dd}.%i.zip"
        maxFileSize = "100MB"
        maxHistory = 60
        totalSizeCap = FileSize.valueOf("20GB")
    }
}

appender("ASYNC", AsyncAppender) {
    appenderRef("FILE")
}

root(INFO, ["CONSOLE", "ASYNC"])


if (Environment.current == Environment.DEVELOPMENT) {
    def targetDir = BuildSettings.TARGET_DIR
    if (targetDir) {

        appender("FULL_STACKTRACE", FileAppender) {

            file = "${targetDir}/stacktrace.log"
            append = true
            encoder(PatternLayoutEncoder) {
                pattern = "%level %logger - %msg%n"
            }
        }
        logger("StackTrace", ERROR, ['FULL_STACKTRACE'], false)
    }

} else {
    logger("StackTrace", OFF)
}

logger("org.springframework.boot.autoconfigure.security", ERROR)
logger("org.hibernate", ERROR)
logger("org.grails.web.errors.GrailsExceptionResolver", OFF)
logger("error.ClValidationException", OFF)