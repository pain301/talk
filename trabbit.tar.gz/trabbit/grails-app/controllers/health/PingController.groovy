package health

import grails.gorm.transactions.Transactional
import org.springframework.transaction.support.TransactionSynchronizationAdapter
import org.springframework.transaction.support.TransactionSynchronizationManager

class PingController {

    def pong() {
        render status: 200, text: "pong"
    }

    def kafkaProducerService

    def kafka() {
        def msg = request.JSON
        kafkaProducerService.send("t0109", "key2019", msg)
        render status: 200, text: "kafka"
    }

    @Transactional
    def test() {
        System.out.println("### before sleep")
        publishSth1()
        publishSth1()
        Thread.sleep(30000)
        System.out.println("### after sleep")
        render status: 200, text: "test"
    }

    def publishSth1() {
        doAfterTransaction(new Runnable() {
            @Override
            void run() {
                System.out.println("### publish sth1.")
            }
        })
    }

    def publishSth2() {
        doAfterTransaction(new Runnable() {
            @Override
            void run() {
                System.out.println("### publish sth2.")
            }
        })
    }


    def doAfterTransaction(Runnable callback) {
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            TransactionSynchronizationManager.registerSynchronization(
                    new TransactionSynchronizationAdapter() {
                        @Override
                        public void afterCommit() {
                            super.afterCommit()
                            callback.run()
                        }

                        @Override
                        void afterCompletion(int status) {
                            super.afterCompletion(status)
                            System.out.println("status: " + status)
                        }
                    }
            )

            def synchronizations = TransactionSynchronizationManager.synchronizations

            log.info("syncer size: ${synchronizations.size()}")

            System.out.println("T active")
        } else {
            callback.run()
            System.out.println("T not active")
        }
    }

}
