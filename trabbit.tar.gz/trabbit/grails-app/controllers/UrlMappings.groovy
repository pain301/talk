package lab

class UrlMappings {

    static mappings = {

        "/ping"(controller: "Ping") {
            action = [GET: "pong"]
        }

        "/kafka"(controller: "Ping") {
            action = [POST: "kafka"]
        }

        "/test"(controller: "Ping") {
            action = [POST: "test"]
        }
    }

}
