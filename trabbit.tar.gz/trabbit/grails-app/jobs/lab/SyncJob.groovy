package lab


import grails.converters.JSON
import grails.gorm.transactions.Transactional

class SyncJob {

    static final String T_EXCHANGE = "t_exchange"
    static final String T_QUEUE = "t_queue"
    static final String T_ROUTINGKEY = "t_key"

    static triggers = {
        simple name: "SyncJob", startDelay: 16000, repeatCount: 0
    }

    def rabbitMQService

    def execute() {
        rabbitMQService.getMessageFromProducer(
                T_EXCHANGE, T_QUEUE, T_ROUTINGKEY, true) { message ->
            processMessage(message)
        }
    }

    @Transactional
    def processMessage(def message) {
        log.info("sync info: ${message as JSON}")
    }

}
