package lab

import grails.converters.JSON
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.consumer.ConsumerRecords
import org.apache.kafka.clients.consumer.KafkaConsumer
import org.apache.kafka.common.PartitionInfo
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.errors.WakeupException
import org.apache.kafka.common.serialization.StringDeserializer

class MonitorConsumerJob {
    static triggers = {
        simple name: "SyncJob", startDelay: 16000, repeatCount: 0
    }

    KafkaConsumer consumer

    def execute() {
        consume()
    }

    def prepare() {
        Properties props = new Properties()
        props.put("bootstrap.servers", "localhost:9092")
        props.put("group.id", "g2019")

        props.put("key.deserializer", StringDeserializer.class.getName())
        props.put("value.deserializer", StringDeserializer.class.getName())

        this.consumer = new KafkaConsumer(props)
        consumer.addShutdownHook {
            consumer.wakeup()
        }
    }

    def consume() {
        prepare()
        try {
            consumer.subscribe(Collections.singletonList("t0109"))

            while (true) {
                ConsumerRecords<String, String> records = consumer.poll(1000)
                for (ConsumerRecord<String, String> record : records) {
                    log.info("### partition: ${record.partition()}, offset: ${record.offset()}, value: ${record.value()}")
                }

                Thread.sleep(1000 * 60)

                Set<TopicPartition> tps = consumer.assignment()
                for (TopicPartition tp in tps) {
                    def beginOffsetsMap = consumer.beginningOffsets(Collections.singletonList(tp))
                    def endOffsetsMap = consumer.endOffsets(Collections.singletonList(tp))
                    log.info("### partition: ${tp.partition()}, position: ${consumer.position(tp)}, commited: ${consumer.committed(tp)}, " +
                            "beginOffsetsMap: ${beginOffsetsMap as JSON}, endOffsetsMap: ${endOffsetsMap}")
                }

                List<PartitionInfo> partitionInfos = consumer.partitionsFor("t0109")
                for (PartitionInfo partitionInfo in partitionInfos) {
                    log.info("### partition info: ${partitionInfo as JSON}")
                }
            }
        } catch (WakeupException e) {
            // ignore for shutdown
        } finally {
            consumer.close()
        }
    }
    // begin, committed, current, end

}
